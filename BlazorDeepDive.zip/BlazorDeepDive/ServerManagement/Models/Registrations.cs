﻿namespace ServerManagement.Models
{
    public class Registrations()
    {

        public int RegistrationId { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Password { get; set; }
        public string? confirmPassword { get; set; }
        public bool termsAndConditions { get; set; }
    }   
}
