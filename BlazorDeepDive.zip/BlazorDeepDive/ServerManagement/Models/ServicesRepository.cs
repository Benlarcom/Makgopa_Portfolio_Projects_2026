﻿namespace ServerManagement.Models
{
    public class ServicesRepository
    {
        private static List<string> services = new List<string>()
        {
            "Carpet",
            "Mattress",
            "Item 3",
            "Item 4",
            "Item 5"
        };

        public static List<string> GetServices() => services;
    }
}
