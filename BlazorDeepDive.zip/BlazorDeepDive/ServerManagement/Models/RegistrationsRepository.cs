﻿namespace ServerManagement.Models
{
    public class RegistrationsRepository
    {
    }
}
