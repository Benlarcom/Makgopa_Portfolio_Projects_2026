﻿using ServerManagement.Components.Pages;

namespace ServerManagement.Models
{
    public class BookingsRepository
    {
        private static List<Booking> bookings = new List<Booking>()
        {
            new Booking { BookingId = 1, Name = "Cindy", Item = "Mattress" },
            new Booking { BookingId = 2, Name = "Celia", Item = "Mattress" }
        };

        public static void AddBooking(Booking booking)
        {
            var maxId = bookings.Max(book => book.BookingId);
            booking.BookingId = maxId + 1;
            bookings.Add(booking);
        }

        public static List<Booking> GetBookings() => bookings;

        public static List<Booking> GetBookingsByItem(string Item)
        {
            return bookings.Where(book => book.Item.Equals(Item, StringComparison.OrdinalIgnoreCase)).ToList();

        }

        public static Booking? GetBookingsById(int id)
        {
            var booking = bookings.FirstOrDefault(book => book.BookingId == id);
            if (booking != null)
            {
                return new Booking
                {
                    BookingId = booking.BookingId,
                    Name = booking.Name,
                    Item = booking.Item
                };
            }

            return null;
        }

        public static void UpdateBooking(int bookingId, Booking booking)
        {
            if (bookingId != booking.BookingId) return;

            var bookingToUpdate = bookings.FirstOrDefault(book => book.BookingId == bookingId);
            if (bookingToUpdate != null)
            {
                bookingToUpdate.BookingId = booking.BookingId;
                bookingToUpdate.Name = bookingToUpdate.Name;
                bookingToUpdate.Item = bookingToUpdate.Item;
                booking.IsComplete = bookingToUpdate.IsComplete;
            }

        }

        public static void DeleteBooking(int bookingId)
        {
            var booking = bookings.FirstOrDefault(book => book.BookingId == bookingId);
            if (booking != null)
            {
                bookings.Remove(booking);
            }
        }

        public static List<Booking> SearchBookings(string bookingFilter)
        {
            return bookings.Where(book => book.Name.Contains(bookingFilter, StringComparison.OrdinalIgnoreCase)).ToList();
        }


    }


}
