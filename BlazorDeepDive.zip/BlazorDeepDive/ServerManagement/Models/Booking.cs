﻿using System.ComponentModel.DataAnnotations;

namespace ServerManagement.Models
{
    public class Booking()
    {
        public Booking()
        {
            Random random = new Random();
            int randomNumber = random.Next(0, 2);
            IsComplete = randomNumber == 0? false : true;
        }

        public int BookingId { get; set; }
        public string? Name { get; set; }
        public string? Item { get; set; }
        public bool IsComplete { get; set; }
    }
}
